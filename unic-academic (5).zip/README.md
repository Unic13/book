# UNIC Academic — Practice Portal

Next.js 14 · Vercel Serverless · Hasura (Postgres) · KaTeX · LaTeX

---

## ⚡ Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.example .env.local
# Edit .env.local and fill in Hasura + admin values

# 3. Start dev server
npm run dev
# → http://localhost:3000
```

The app works **without Hasura** — all 4 subjects load from the bundled
`/data/*.json` files.  Hasura is only needed to persist admin-authored
content and registration/attempt data.

---

## 🗄️ Set Up Hasura (optional but recommended)

1. Create a free project at [cloud.hasura.io](https://cloud.hasura.io)
2. In Hasura Console → **Data → SQL**, run `hasura/migrations/001_init.sql`
3. Go to **Data → Track Tables** → track `registrations`, `attempts`, `subject_content`
4. Copy your **GraphQL endpoint** and **Admin Secret** into `.env.local`

---

## 🚀 Deploy to Vercel

```bash
# Install Vercel CLI once
npm i -g vercel

# Deploy
vercel

# Or link to GitHub and auto-deploy via Vercel Dashboard
```

**Required env vars in Vercel Dashboard → Settings → Environment Variables:**

| Variable | Value |
|---|---|
| `HASURA_GRAPHQL_URL` | `https://your-app.hasura.app/v1/graphql` |
| `HASURA_ADMIN_SECRET` | your Hasura admin secret |
| `ADMIN_KEY` | a password you choose (default: `unic_admin_2024`) |
| `BLOB_READ_WRITE_TOKEN` | *(optional)* from Vercel Blob storage for image uploads |

---

## 🏗️ Project Structure

```
pages/
  index.js              ← Main learning app (subjects / chapters / questions)
  admin/index.js        ← Admin dashboard + Question Builder
  api/
    register.js         ← POST: save registration
    attempt.js          ← POST: save question attempt
    content.js          ← GET (public) / POST+DELETE (admin): subject content
    upload-image.js     ← POST (admin): image → Vercel Blob or base64
    admin/
      stats.js          ← GET: aggregate stats
      registrations.js  ← GET: paginated registrations table
      attempts.js       ← GET: paginated attempts table

lib/
  hasura.js             ← GraphQL client (server-side only)
  auth.js               ← Admin key check
  image-upload.js       ← Vercel Blob + base64 fallback

data/                   ← Bundled fallback JSON (loaded if Hasura has no content)
  config.json
  physics.json
  chemistry.json
  mathematics.json
  biology.json

hasura/migrations/
  001_init.sql          ← Run this in Hasura Console to create tables
```

---

## ✏️ Admin Question Builder

Visit `/admin` → enter your `ADMIN_KEY` → click **Question Builder** tab.

- Add / rename / delete **Units** and **Chapters**
- Edit each chapter's **Concept** (title, body paragraphs with **bold** + `$LaTeX$`, key formulas, optional image)
- Add **MCQ**, **MSQ**, and **NAT** (numerical) questions with options, correct-answer selection, explanation, and optional image
- **Upload images** — stored in Vercel Blob (if configured) or as base64 inline
- **Preview JSON** to see the exact document saved
- **Save to Database** — upserts into Hasura; the main app reads this live
- **Download JSON** — export to commit into `/data/` as a static fallback

---

## 📐 Question JSON Schema

```jsonc
{
  "id":    "ph_q1",
  "type":  "MCQ",          // "MCQ" | "MSQ" | "NAT"
  "latex": true,
  "image": null,           // null | URL | base64 data URI
  "question": "If $F=ma$ and $m=2$, find $a$ when $F=10$.",
  "options": ["3","4","5","6"],   // omit for NAT
  "answer":  [2],                 // 0-indexed array; number for NAT
  // NAT only:
  "answer":    5,
  "tolerance": 0.1,
  "unit":      "m/s²",
  "explanation": "..."
}
```
