import { useState, useEffect, useCallback, useRef } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import configData from '../data/config.json';

// ─── helpers ────────────────────────────────────────────────────────────────
function hex2rgba(hex, a) {
  const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${a})`;
}
function uid(p){ return `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`; }

function checkCorrect(q, selected) {
  if (q.type==='NAT') {
    const v=parseFloat(selected); if(isNaN(v)) return false;
    return Math.abs(v-q.answer)<=(q.tolerance??0);
  }
  const a=[...(selected||[])].sort((a,b)=>a-b);
  const b=[...(q.answer||[])].sort((a,b)=>a-b);
  return JSON.stringify(a)===JSON.stringify(b);
}

const STATIC_FILES = {PH:'/data_ph',CH:'/data_ch',MA:'/data_ma',BIO:'/data_bio'};

// ─── Main page ───────────────────────────────────────────────────────────────
export default function Home({ config }) {
  const [showWelcome, setShowWelcome] = useState(false);
  const [userData, setUserData]       = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Subject state
  const subjects = config.subjects;
  const [activeCode, setActiveCode]   = useState(subjects[0]?.code || 'PH');
  const [subjectData, setSubjectData] = useState(null);
  const [loading, setLoading]         = useState(true);

  // Chapter/question state
  const [activeChapterId, setActiveChapterId] = useState(null);
  const [qtypeFilter, setQtypeFilter]         = useState('ALL');
  const [questionIndex, setQuestionIndex]     = useState(0);
  const [conceptOpen, setConceptOpen]         = useState(true);
  const [answers, setAnswers]                 = useState({});
  const [submitted, setSubmitted]             = useState({});

  // Bootstrap: check localStorage for saved user
  useEffect(() => {
    const saved = localStorage.getItem('unic_user');
    if (saved) { try { setUserData(JSON.parse(saved)); } catch {} }
    else setShowWelcome(true);
  }, []);

  // Load subject data (try Hasura, fallback to bundled JSON file via Next.js API)
  useEffect(() => {
    setLoading(true);
    setSubjectData(null);
    setActiveChapterId(null);
    setQuestionIndex(0);
    setQtypeFilter('ALL');
    setConceptOpen(true);

    // Try DB first
    fetch(`/api/content?code=${activeCode}`)
      .then(r => r.json())
      .then(json => {
        if (json?.data?.units) return json.data;
        throw new Error('not in db');
      })
      .catch(() => {
        // Fallback: import the static JSON bundled at build time via getStaticProps
        return fetch(`/_next/static/chunks/data/${activeCode.toLowerCase()}.json`)
          .then(r=>r.json())
          .catch(() => null);
      })
      .then(data => {
        if (data) {
          setSubjectData(data);
          const first = data.units?.[0]?.chapters?.[0];
          if (first) setActiveChapterId(first.id);
        }
        setLoading(false);
      });
  }, [activeCode]);

  // Computed helpers
  const allChapters = subjectData?.units?.flatMap(u=>u.chapters) || [];
  const chapter = allChapters.find(c=>c.id===activeChapterId);
  const allQs   = chapter?.questions || [];
  const questions = qtypeFilter==='ALL' ? allQs : allQs.filter(q=>q.type===qtypeFilter);
  const q       = questions[questionIndex] || null;
  const color   = subjects.find(s=>s.code===activeCode)?.color || '#6C3FF5';

  const chapIdx  = allChapters.findIndex(c=>c.id===activeChapterId);
  const canNext  = questionIndex < questions.length-1 || chapIdx < allChapters.length-1;
  const canPrev  = questionIndex > 0 || chapIdx > 0;

  function selectChapter(id) {
    setActiveChapterId(id);
    setQuestionIndex(0);
    setQtypeFilter('ALL');
    setConceptOpen(true);
    if (window.innerWidth < 768) setSidebarOpen(false);
  }

  function handleOptionToggle(idx) {
    if (!q || submitted[q.id]) return;
    const prev = answers[q.id] || [];
    if (q.type==='MCQ') { setAnswers(a=>({...a,[q.id]:[idx]})); }
    else { setAnswers(a=>({...a,[q.id]: prev.includes(idx)?prev.filter(x=>x!==idx):[...prev,idx]})); }
  }

  function handleNatChange(val) {
    if (!q || submitted[q.id]) return;
    setAnswers(a=>({...a,[q.id]:val}));
  }

  function handleSubmit() {
    if (!q || submitted[q.id]) return;
    const sel = answers[q.id];
    if (q.type==='NAT') { if(!String(sel??'').trim()) return; }
    else { if(!(sel?.length)) return; }
    setSubmitted(s=>({...s,[q.id]:true}));
    const isCorrect = checkCorrect(q, sel);
    if (userData) {
      fetch('/api/attempt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
        userId:userData.email||userData.name||'guest',questionId:q.id,subject:activeCode,
        chapterId:activeChapterId,questionType:q.type,selected:sel,correct:q.answer,isCorrect,
      })}).catch(()=>{});
    }
  }

  function handleNext() {
    if (questionIndex<questions.length-1) { setQuestionIndex(i=>i+1); }
    else if (chapIdx<allChapters.length-1) {
      const next=allChapters[chapIdx+1];
      setActiveChapterId(next.id);
      setQuestionIndex(0);
      setQtypeFilter('ALL');
      setConceptOpen(true);
    }
  }

  function handlePrev() {
    if (questionIndex>0) { setQuestionIndex(i=>i-1); }
    else if (chapIdx>0) {
      const prev=allChapters[chapIdx-1];
      setActiveChapterId(prev.id);
      const pQs = qtypeFilter==='ALL' ? prev.questions||[] : (prev.questions||[]).filter(x=>x.type===qtypeFilter);
      setQuestionIndex(Math.max(0,pQs.length-1));
    }
  }

  function handleRegister(form) {
    setUserData(form);
    localStorage.setItem('unic_user', JSON.stringify(form));
    setShowWelcome(false);
    fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)}).catch(()=>{});
  }

  // counts for submitted per chapter (for sidebar badge)
  function chapProgress(ch) {
    const total=ch.questions?.length||0;
    const done=ch.questions?.filter(q=>submitted[q.id]).length||0;
    return {total,done,pct:total?Math.round(done/total*100):0};
  }

  const subjColor = color;

  return (
    <>
      <Head>
        <title>{config.academyName} — Practice Portal</title>
        <meta name="description" content={config.tagline} />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
      </Head>

      {showWelcome && <WelcomeModal config={config} onRegister={handleRegister} onSkip={()=>setShowWelcome(false)} />}

      <div style={{display:'flex',flexDirection:'column',height:'100vh',overflow:'hidden'}}>
        {/* ── Top Bar ── */}
        <TopBar
          config={config} subjects={subjects} activeCode={activeCode}
          onSubjectChange={code=>{setActiveCode(code);setAnswers({});setSubmitted({});}}
          userData={userData} sidebarOpen={sidebarOpen} onToggleSidebar={()=>setSidebarOpen(v=>!v)}
        />

        <div style={{display:'flex',flex:1,overflow:'hidden'}}>
          {/* ── Sidebar ── */}
          <Sidebar
            open={sidebarOpen} subjectData={subjectData} loading={loading}
            activeChapterId={activeChapterId} onChapterSelect={selectChapter}
            color={subjColor} chapProgress={chapProgress}
          />

          {/* ── Main content ── */}
          <main style={{flex:1,overflowY:'auto',padding:'24px 20px'}}>
            {loading ? (
              <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200}}>
                <div style={{width:36,height:36,border:'3px solid #e5e7eb',borderRadius:'50%',borderTopColor:subjColor,animation:'spin .7s linear infinite'}} />
              </div>
            ) : !chapter ? (
              <Empty icon="📖" text="Select a chapter from the sidebar to begin" />
            ) : (
              <QuestionPanel
                chapter={chapter} questions={questions} questionIndex={questionIndex}
                qtypeFilter={qtypeFilter} onQtypeFilterChange={f=>{setQtypeFilter(f);setQuestionIndex(0);}}
                selectedAnswer={q?answers[q.id]:undefined}
                isSubmitted={q?!!submitted[q.id]:false}
                onOptionToggle={handleOptionToggle} onNatChange={handleNatChange}
                onSubmit={handleSubmit} onNext={handleNext} onPrev={handlePrev}
                canNext={canNext} canPrev={canPrev}
                onGoToDot={i=>setQuestionIndex(i)}
                color={subjColor} conceptOpen={conceptOpen}
                onToggleConcept={()=>setConceptOpen(v=>!v)}
              />
            )}
          </main>
        </div>
      </div>

      <style jsx global>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        .fade-in{animation:fadeUp .25s ease-out}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
      `}</style>
    </>
  );
}

// ─── getStaticProps: pass config + bundle subject data ──────────────────────
export async function getStaticProps() {
  return { props: { config: configData } };
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTS
// ══════════════════════════════════════════════════════════════════════════════

// ─── TopBar ──────────────────────────────────────────────────────────────────
function TopBar({ config, subjects, activeCode, onSubjectChange, userData, sidebarOpen, onToggleSidebar }) {
  const [ddOpen, setDdOpen] = useState(false);
  return (
    <header style={{height:56,background:'#fff',borderBottom:'1px solid #e5e7eb',display:'flex',alignItems:'center',gap:12,padding:'0 16px',flexShrink:0,zIndex:30,boxShadow:'0 1px 3px rgba(0,0,0,.06)'}}>
      <button onClick={onToggleSidebar} style={{background:'none',border:'none',padding:7,borderRadius:8,color:'#6b7280',display:'flex'}}>
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
      <div style={{width:34,height:34,borderRadius:10,background:'linear-gradient(135deg,#7c3aed,#4f46e5)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,color:'#fff',fontSize:11,flexShrink:0}}>{config.logoText}</div>
      <span style={{fontWeight:700,fontSize:14,color:'#111',whiteSpace:'nowrap'}}>{config.academyName}</span>
      <nav style={{display:'flex',gap:6,flex:1,overflowX:'auto',marginLeft:4}}>
        {subjects.map(s=>{
          const active=s.code===activeCode;
          return (
            <button key={s.code} onClick={()=>onSubjectChange(s.code)}
              style={{display:'flex',alignItems:'center',gap:6,padding:'6px 14px',borderRadius:9,fontSize:13,fontWeight:600,whiteSpace:'nowrap',border:`1.5px solid ${active?'transparent':hex2rgba(s.color,.25)}`,background:active?s.color:hex2rgba(s.color,.08),color:active?'#fff':s.color,boxShadow:active?`0 2px 8px ${hex2rgba(s.color,.35)}`:'none'}}>
              <span style={{fontSize:15,lineHeight:1}}>{s.emoji}</span>
              <span>{s.subject}</span>
            </button>
          );
        })}
      </nav>
      <div style={{position:'relative',marginLeft:'auto'}}>
        <button onClick={()=>setDdOpen(v=>!v)}
          style={{width:34,height:34,borderRadius:'50%',background:'linear-gradient(135deg,#8b5cf6,#4f46e5)',border:'none',color:'#fff',fontWeight:700,fontSize:12,display:'flex',alignItems:'center',justifyContent:'center'}}>
          {userData?.name?userData.name[0].toUpperCase():'?'}
        </button>
        {ddOpen&&(
          <div style={{position:'absolute',right:0,top:42,background:'#fff',border:'1px solid #e5e7eb',borderRadius:14,padding:14,minWidth:200,boxShadow:'0 4px 12px rgba(0,0,0,.1)',zIndex:50}}>
            <div style={{fontWeight:600,fontSize:13,color:'#111'}}>{userData?.name||'Guest'}</div>
            {userData?.email&&<div style={{fontSize:11,color:'#9ca3af',marginTop:2}}>{userData.email}</div>}
            <hr style={{border:'none',borderTop:'1px solid #f3f4f6',margin:'10px 0'}}/>
            <Link href="/admin" style={{display:'flex',alignItems:'center',gap:7,fontSize:12,color:'#6b7280',padding:'4px 0'}}>⚙️ Admin Panel</Link>
            <button onClick={()=>{localStorage.removeItem('unic_user');window.location.reload();}}
              style={{display:'flex',alignItems:'center',gap:7,fontSize:12,color:'#6b7280',padding:'4px 0',background:'none',border:'none',width:'100%',marginTop:8}}>🚪 Sign out</button>
          </div>
        )}
      </div>
    </header>
  );
}

// ─── Sidebar ─────────────────────────────────────────────────────────────────
function Sidebar({ open, subjectData, loading, activeChapterId, onChapterSelect, color, chapProgress }) {
  const [collapsed, setCollapsed] = useState({});
  if (!open) return null;
  return (
    <aside style={{width:256,minWidth:256,background:'#fff',borderRight:'1px solid #e5e7eb',display:'flex',flexDirection:'column',overflow:'hidden',flexShrink:0}}>
      {subjectData&&<div style={{padding:'12px 16px',borderBottom:'1px solid #f3f4f6',background:hex2rgba(color,.06)}}>
        <p style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.08em',color}}>{subjectData.subject}</p>
        <p style={{fontSize:11,color:'#9ca3af',marginTop:2}}>{subjectData.units?.reduce((a,u)=>a+(u.chapters?.length||0),0)} chapters</p>
      </div>}
      <div style={{flex:1,overflowY:'auto',padding:'6px 0'}}>
        {loading?<SkeletonList/>:subjectData?.units?.map(unit=>{
          const col=collapsed[unit.id];
          return(
            <div key={unit.id} style={{marginBottom:2}}>
              <button onClick={()=>setCollapsed(c=>({...c,[unit.id]:!c[unit.id]}))}
                style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'9px 16px',background:'none',border:'none',cursor:'pointer'}}>
                <span style={{fontSize:12,fontWeight:600,color:'#374151',textAlign:'left'}}>{unit.title}</span>
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{color:'#9ca3af',transform:col?'rotate(-90deg)':'none',transition:'transform .2s',flexShrink:0}}>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/>
                </svg>
              </button>
              {!col&&<div style={{marginLeft:14,paddingLeft:10,borderLeft:'2px solid #f3f4f6'}}>
                {unit.chapters?.map(ch=>{
                  const active=ch.id===activeChapterId;
                  const {total,done,pct}=chapProgress(ch);
                  return(
                    <button key={ch.id} onClick={()=>onChapterSelect(ch.id)}
                      style={{width:'100%',textAlign:'left',padding:'9px 12px',borderRadius:9,border:'none',marginBottom:2,background:active?color:'transparent',color:active?'#fff':'#6b7280',cursor:'pointer'}}>
                      <p style={{fontSize:12,fontWeight:500,lineHeight:1.4}}>{ch.title}</p>
                      <div style={{display:'flex',alignItems:'center',gap:6,marginTop:5}}>
                        <div style={{flex:1,height:3,borderRadius:2,background:active?'rgba(255,255,255,.3)':'#e5e7eb'}}>
                          <div style={{height:'100%',borderRadius:2,width:`${pct}%`,background:active?'#fff':color,transition:'width .3s'}}/>
                        </div>
                        <span style={{fontSize:10,color:active?'rgba(255,255,255,.7)':'#9ca3af'}}>{done}/{total}</span>
                      </div>
                    </button>
                  );
                })}
              </div>}
            </div>
          );
        })}
      </div>
    </aside>
  );
}

// ─── QuestionPanel ────────────────────────────────────────────────────────────
function QuestionPanel({ chapter, questions, questionIndex, qtypeFilter, onQtypeFilterChange,
  selectedAnswer, isSubmitted, onOptionToggle, onNatChange, onSubmit, onNext, onPrev,
  canNext, canPrev, onGoToDot, color, conceptOpen, onToggleConcept }) {

  const q = questions[questionIndex];
  const allQs = chapter?.questions || [];
  const counts = {ALL:allQs.length,MCQ:allQs.filter(x=>x.type==='MCQ').length,MSQ:allQs.filter(x=>x.type==='MSQ').length,NAT:allQs.filter(x=>x.type==='NAT').length};

  return (
    <div style={{maxWidth:720,margin:'0 auto'}} className="fade-in">
      {chapter?.concept&&<ConceptCard concept={chapter.concept} color={color} open={conceptOpen} onToggle={onToggleConcept}/>}

      {/* Type filter tabs */}
      <div style={{display:'flex',gap:6,marginBottom:16}}>
        {['ALL','MCQ','MSQ','NAT'].map(t=>{
          if(t!=='ALL'&&counts[t]===0) return null;
          const act=qtypeFilter===t;
          return(
            <button key={t} onClick={()=>onQtypeFilterChange(t)} style={{padding:'7px 14px',borderRadius:9,fontSize:12.5,fontWeight:700,border:act?'1.5px solid transparent':'1.5px solid #e5e7eb',background:act?color:'#fff',color:act?'#fff':'#6b7280'}}>
              {t==='ALL'?'All':t}
              <span style={{marginLeft:5,fontSize:10.5,background:act?'rgba(255,255,255,.25)':'#f3f4f6',color:act?'#fff':'#9ca3af',borderRadius:10,padding:'1px 6px'}}>{counts[t]}</span>
            </button>
          );
        })}
      </div>

      {!q ? <Empty icon="📭" text={`No ${qtypeFilter!=='ALL'?qtypeFilter:''} questions in this chapter`}/>
        : <QCard q={q} idx={questionIndex} total={questions.length} chapterTitle={chapter?.title}
            sel={selectedAnswer} submitted={isSubmitted}
            onToggle={onOptionToggle} onNat={onNatChange} onSubmit={onSubmit}
            onNext={onNext} onPrev={onPrev} canNext={canNext} canPrev={canPrev}
            onDot={onGoToDot} color={color}/>
      }
    </div>
  );
}

// ─── ConceptCard ─────────────────────────────────────────────────────────────
function ConceptCard({ concept, color, open, onToggle }) {
  const latexRef = useLatexRender(open, concept.latex);
  return (
    <div style={{background:'#fff',borderRadius:18,border:'1px solid #e5e7eb',boxShadow:'var(--shadow)',overflow:'hidden',marginBottom:22}}>
      <div onClick={onToggle} style={{display:'flex',alignItems:'center',gap:10,padding:'14px 20px',cursor:'pointer',userSelect:'none',borderBottom:open?'1px solid #f3f4f6':'none'}}>
        <div style={{width:34,height:34,borderRadius:10,background:color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0}}>💡</div>
        <div style={{flex:1}}>
          <div style={{fontSize:10.5,fontWeight:700,letterSpacing:'.08em',textTransform:'uppercase',color,opacity:.85}}>Concept</div>
          <div style={{fontSize:14.5,fontWeight:700,color:'#111',marginTop:1}}>{concept.title}</div>
        </div>
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{color:'#9ca3af',transform:open?'rotate(180deg)':'none',transition:'transform .25s',flexShrink:0}}>
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/>
        </svg>
      </div>
      {open&&(
        <div ref={latexRef} style={{padding:'4px 22px 20px'}}>
          {concept.image&&<img src={concept.image} alt={concept.title} style={{width:'100%',borderRadius:12,border:'1px solid #f0f0f0',marginBottom:14,marginTop:10}}/>}
          {(concept.body||[]).map((para,i)=>(
            <p key={i} style={{fontSize:13.5,lineHeight:1.85,color:'#374151',marginBottom:13}}
              dangerouslySetInnerHTML={{__html:boldMarkdown(para)}}/>
          ))}
          {!!(concept.formulas||[]).length&&(
            <div style={{marginTop:14,padding:'14px 16px',borderRadius:12,background:'#f9fafb',border:'1px solid #f0f0f0'}}>
              <div style={{fontSize:10.5,fontWeight:700,letterSpacing:'.07em',textTransform:'uppercase',color:'#9ca3af',marginBottom:9}}>Key Formulas</div>
              {concept.formulas.map((f,i)=>(
                <span key={i} style={{display:'inline-block',background:'#fff',border:'1px solid #e5e7eb',borderRadius:8,padding:'6px 12px',margin:'0 6px 6px 0',fontSize:13,color:'#1f2937'}}>{f}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── QCard (question display) ─────────────────────────────────────────────────
function QCard({ q, idx, total, chapterTitle, sel, submitted, onToggle, onNat, onSubmit, onNext, onPrev, canNext, canPrev, onDot, color }) {
  const pct = ((idx+1)/total)*100;
  const hasAnswer = q.type==='NAT'
    ? String(sel??'').trim()!==''
    : Array.isArray(sel)&&sel.length>0;
  const isRight = submitted&&checkCorrect(q,sel);

  const latexRef = useLatexRender(true, q.latex);

  return (
    <>
      <p style={{fontSize:11,color:'#9ca3af',fontWeight:600,letterSpacing:'.06em',textTransform:'uppercase',marginBottom:10}}>{chapterTitle}</p>
      <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:18}}>
        <div style={{flex:1,height:5,background:'#e5e7eb',borderRadius:3,overflow:'hidden'}}>
          <div style={{height:'100%',width:`${pct}%`,background:color,borderRadius:3,transition:'width .4s'}}/>
        </div>
        <span style={{fontSize:12,fontWeight:600,color:'#9ca3af',whiteSpace:'nowrap'}}>{idx+1} / {total}</span>
      </div>

      <div style={{background:'#fff',borderRadius:18,border:'1px solid #e5e7eb',boxShadow:'var(--shadow)',overflow:'hidden'}}>
        {/* Header */}
        <div style={{display:'flex',alignItems:'center',gap:10,padding:'12px 20px',borderBottom:'1px solid #f3f4f6',background:hex2rgba(color,.06)}}>
          <span style={{fontSize:11,fontWeight:700,padding:'3px 10px',borderRadius:20,color:'#fff',background:color}}>{q.type}</span>
          {q.type==='MSQ'&&<span style={{fontSize:12,color:'#9ca3af'}}>Select all correct answers</span>}
          {q.type==='NAT'&&<span style={{fontSize:12,color:'#9ca3af'}}>Enter a numeric value</span>}
          <span style={{marginLeft:'auto',fontSize:12,color:'#c4c4c4',fontWeight:600}}>Q{idx+1}</span>
        </div>

        {/* Question body */}
        <div ref={latexRef} style={{padding:'20px 22px'}}>
          <p style={{fontSize:15,color:'#111',lineHeight:1.7,fontWeight:500}} dangerouslySetInnerHTML={{__html:boldMarkdown(q.question)}}/>
          {q.image&&<img src={q.image} alt="Question diagram" style={{width:'100%',maxHeight:320,objectFit:'contain',borderRadius:12,border:'1px solid #f0f0f0',background:'#fafafa',marginTop:14}}/>}
        </div>

        {/* Input area */}
        {q.type==='NAT'
          ? <NatInput q={q} value={sel} submitted={submitted} onChange={onNat}/>
          : <div style={{padding:'0 22px 20px',display:'flex',flexDirection:'column',gap:10}}>
              {q.options.map((opt,i)=>(
                <OptionBtn key={i} idx={i} text={opt} answer={q.answer} sel={sel||[]} submitted={submitted} onToggle={onToggle} latex={q.latex}/>
              ))}
            </div>
        }

        {/* Explanation */}
        {submitted&&q.explanation&&(
          <div style={{margin:'0 22px 20px',padding:'14px 16px',borderRadius:12,border:`1.5px solid ${isRight?'#86efac':'#fca5a5'}`,background:isRight?'#f0fdf4':'#fef2f2',color:isRight?'#15803d':'#b91c1c',fontSize:13,lineHeight:1.7}}>
            <div style={{fontWeight:700,marginBottom:5,fontSize:14}}>{isRight?'🎉 Correct!':'💡 Not quite — here\'s why:'}</div>
            <span dangerouslySetInnerHTML={{__html:boldMarkdown(q.explanation)}}/>
          </div>
        )}

        {/* Actions */}
        <div style={{padding:'0 22px 20px',display:'flex',alignItems:'center',gap:10}}>
          <button onClick={onPrev} disabled={!canPrev} style={{...btnStyle('outline'),opacity:canPrev?1:.35}}>
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/></svg> Prev
          </button>
          {!submitted
            ?<button onClick={onSubmit} disabled={!hasAnswer} style={{...btnStyle('primary',color),opacity:hasAnswer?1:.4,flex:1}}>Check Answer</button>
            :<button onClick={onNext} disabled={!canNext} style={{...btnStyle('primary',color),opacity:canNext?1:.4,flex:1}}>{idx<total-1?'Next Question →':'Next Chapter →'}</button>
          }
          <button onClick={onNext} disabled={!canNext} style={{...btnStyle('outline'),opacity:canNext?1:.35}}>
            Next <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"/></svg>
          </button>
        </div>
      </div>

      {/* Dots */}
      <div style={{display:'flex',justifyContent:'center',gap:6,marginTop:14,flexWrap:'wrap'}}>
        {Array.from({length:total}).map((_,i)=>(
          <div key={i} onClick={()=>onDot(i)} style={{height:6,width:i===idx?18:6,borderRadius:3,background:i===idx?color:'#d1d5db',cursor:'pointer',transition:'all .25s'}}/>
        ))}
      </div>
    </>
  );
}

// ─── OptionBtn ────────────────────────────────────────────────────────────────
const LABELS=['A','B','C','D','E','F'];
function OptionBtn({ idx, text, answer, sel, submitted, onToggle, latex }) {
  let state='idle', label=LABELS[idx];
  if (submitted) {
    const correct=answer.includes(idx), selected=sel.includes(idx);
    if(correct&&selected){state='correct';label='✓';}
    else if(correct){state='missed';label='✓';}
    else if(selected){state='wrong';label='✗';}
  } else if(sel.includes(idx)) state='selected';

  const styles={idle:{border:'2px solid #e5e7eb',bg:'#fff'},selected:{border:'2px solid #6C3FF5',bg:'#f0ebff'},correct:{border:'2px solid #16a34a',bg:'#f0fdf4'},missed:{border:'2px solid #86efac',bg:'#f0fdf4',opacity:.8},wrong:{border:'2px solid #ef4444',bg:'#fef2f2'}};
  const lbg={idle:{bg:'#f3f4f6',c:'#6b7280'},selected:{bg:'#6C3FF5',c:'#fff'},correct:{bg:'#16a34a',c:'#fff'},missed:{bg:'#22c55e',c:'#fff'},wrong:{bg:'#ef4444',c:'#fff'}};
  const s=styles[state]||styles.idle; const l=lbg[state]||lbg.idle;
  const disabled=state==='correct'||state==='missed'||state==='wrong';
  const latexRef = useLatexRender(!!latex, latex);

  return (
    <button onClick={()=>onToggle(idx)} disabled={disabled}
      style={{display:'flex',alignItems:'flex-start',gap:12,padding:'13px 15px',borderRadius:11,border:s.border,background:s.bg,cursor:disabled?'default':'pointer',textAlign:'left',width:'100%',opacity:s.opacity||1}}>
      <span style={{width:28,height:28,borderRadius:8,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,background:l.bg,color:l.c}}>{label}</span>
      <span ref={latexRef} style={{fontSize:13.5,color:'#374151',lineHeight:1.6,flex:1,paddingTop:2}} dangerouslySetInnerHTML={{__html:boldMarkdown(text)}}/>
    </button>
  );
}

// ─── NatInput ─────────────────────────────────────────────────────────────────
function NatInput({ q, value, submitted, onChange }) {
  const isRight = submitted&&checkCorrect(q,value);
  return (
    <div style={{padding:'0 22px 4px'}}>
      <div style={{display:'flex',alignItems:'center',gap:10}}>
        <input type="number" step="any" placeholder="Enter your answer" value={value??''} disabled={submitted}
          onChange={e=>onChange(e.target.value)}
          style={{flex:1,padding:'13px 16px',borderRadius:11,border:`2px solid ${submitted?(isRight?'#16a34a':'#ef4444'):'#e5e7eb'}`,fontSize:15,fontFamily:'inherit',fontWeight:600,color:'#111',outline:'none',background:submitted?(isRight?'#f0fdf4':'#fef2f2'):'#fff'}}/>
        {q.unit&&<span style={{fontSize:13,color:'#9ca3af',fontWeight:600,whiteSpace:'nowrap'}}>{q.unit}</span>}
      </div>
      {submitted&&!isRight&&<div style={{fontSize:12,color:'#16a34a',marginTop:8,fontWeight:600}}>✓ Correct: {q.answer}{q.unit?` ${q.unit}`:''}</div>}
    </div>
  );
}

// ─── WelcomeModal ─────────────────────────────────────────────────────────────
function WelcomeModal({ config, onRegister, onSkip }) {
  const [form,setForm]=useState({name:'',email:'',mobile:'',source:''});
  const [errors,setErrors]=useState({});
  const [saving,setSaving]=useState(false);
  function validate(){const e={};if(form.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))e.email='Invalid email';if(form.mobile&&!/^\+?[\d\s-]{7,15}$/.test(form.mobile))e.mobile='Invalid mobile';return e;}
  function submit(){const e=validate();if(Object.keys(e).length){setErrors(e);return;}setSaving(true);onRegister(form);}
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.6)',backdropFilter:'blur(4px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
      <div style={{background:'#fff',borderRadius:22,width:'100%',maxWidth:420,overflow:'hidden',boxShadow:'0 20px 60px rgba(0,0,0,.2)'}}>
        <div style={{height:5,background:'linear-gradient(90deg,#7c3aed,#6366f1,#4f46e5)'}}/>
        <div style={{padding:32}}>
          <div style={{width:52,height:52,borderRadius:16,margin:'0 auto 14px',background:'linear-gradient(135deg,#7c3aed,#4f46e5)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,color:'#fff',fontSize:14}}>{config.logoText}</div>
          <h2 style={{fontSize:22,fontWeight:800,color:'#111',textAlign:'center',marginBottom:5}}>Welcome to {config.academyName}</h2>
          <p style={{fontSize:13,color:'#9ca3af',textAlign:'center',marginBottom:22}}>Save progress &amp; get updates. <em style={{color:'#7c3aed',fontStyle:'normal',fontWeight:600}}>All optional.</em></p>
          {[['Full Name','text','name','e.g. Priya Sharma'],['Email','email','email','you@example.com'],['Mobile','tel','mobile','+91 98765 43210']].map(([label,type,key,ph])=>(
            <div key={key} style={{marginBottom:14}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,color:'#7c3aed',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:6}}>{label}</label>
              <input type={type} placeholder={ph} value={form[key]} onChange={e=>setForm(f=>({...f,[key]:e.target.value}))}
                style={{width:'100%',padding:'12px 14px',borderRadius:11,border:`1.5px solid ${errors[key]?'#ef4444':'#e5e7eb'}`,background:errors[key]?'#fef2f2':'#f9fafb',fontSize:13,fontFamily:'inherit',outline:'none'}}/>
              {errors[key]&&<p style={{color:'#ef4444',fontSize:11,marginTop:4}}>{errors[key]}</p>}
            </div>
          ))}
          <div style={{marginBottom:14}}>
            <label style={{display:'block',fontSize:11,fontWeight:700,color:'#7c3aed',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:6}}>How Did You Find Us?</label>
            <select value={form.source} onChange={e=>setForm(f=>({...f,source:e.target.value}))} style={{width:'100%',padding:'12px 14px',borderRadius:11,border:'1.5px solid #e5e7eb',background:'#f9fafb',fontSize:13,fontFamily:'inherit',outline:'none'}}>
              <option value="">Select one</option>
              {config.howDidYouFindUs.map(o=><option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          <button onClick={submit} disabled={saving} style={{width:'100%',padding:13,borderRadius:12,border:'none',background:'linear-gradient(135deg,#7c3aed,#4f46e5)',color:'#fff',fontSize:14,fontWeight:700,fontFamily:'inherit',marginBottom:10,cursor:'pointer'}}>
            {saving?'Saving…':'Start Practising →'}
          </button>
          <button onClick={onSkip} style={{width:'100%',padding:10,borderRadius:12,border:'none',background:'none',fontSize:13,color:'#9ca3af',fontFamily:'inherit',cursor:'pointer'}}>Skip for now</button>
        </div>
      </div>
    </div>
  );
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function SkeletonList() {
  return <div style={{padding:12}}>{[1,2,3,4].map(i=><div key={i} style={{height:14,background:'#f3f4f6',borderRadius:6,marginBottom:12}}/>)}</div>;
}
function Empty({icon,text}) {
  return <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:220,color:'#9ca3af',gap:8,textAlign:'center'}}><div style={{fontSize:40}}>{icon}</div><p>{text}</p></div>;
}
function btnStyle(type,color='#6C3FF5') {
  const base={display:'inline-flex',alignItems:'center',gap:6,padding:'10px 18px',borderRadius:10,fontSize:13,fontWeight:600,border:'none',cursor:'pointer'};
  if(type==='outline') return {...base,border:'1.5px solid #e5e7eb',background:'#fff',color:'#6b7280'};
  return {...base,background:color,color:'#fff',boxShadow:`0 2px 8px ${hex2rgba(color,.3)}`};
}
function boldMarkdown(text) {
  return String(text??'').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
}

// Hook: trigger KaTeX auto-render inside a ref'd element whenever content changes
function useLatexRender(enabled, dep) {
  const ref = useRef(null);
  useEffect(() => {
    if (!enabled || !ref.current) return;
    function tryRender() {
      if (typeof window !== 'undefined' && window.renderMathInElement) {
        window.renderMathInElement(ref.current, {
          delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}],
          throwOnError:false,
        });
      } else {
        setTimeout(tryRender, 80);
      }
    }
    tryRender();
  },[enabled, dep]);
  return ref;
}
