import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import Link from 'next/link';

/* ════════════════════════════════════════════════════════════════════════════
   UNIC ACADEMIC — ADMIN PANEL
   Tabs: Data (registrations / attempts) | Question Builder (create / edit /
         preview / delete questions, concepts, images per chapter)
════════════════════════════════════════════════════════════════════════════ */

const BUILTIN = [
  { code:'PH',  subject:'Physics',     color:'#6C3FF5' },
  { code:'CH',  subject:'Chemistry',   color:'#E53E3E' },
  { code:'MA',  subject:'Mathematics', color:'#2563EB' },
  { code:'BIO', subject:'Biology',     color:'#16a34a' },
];
const STATIC_MAP  = { PH:'physics', CH:'chemistry', MA:'mathematics', BIO:'biology' };
const QTYPE_COLOR = { MCQ:'#6C3FF5', MSQ:'#0891b2', NAT:'#d97706' };
const LABELS      = ['A','B','C','D','E','F'];
const PAGE_SIZE   = 50;

function uid(p){ return `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`; }
function bold(t){ return String(t??'').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>'); }

/* ── KaTeX hook: renders math inside a ref whenever `dep` changes ── */
function useLatex(dep) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    function render() {
      if (window.renderMathInElement) {
        window.renderMathInElement(ref.current, {
          delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}],
          throwOnError:false,
        });
      } else setTimeout(render, 80);
    }
    render();
  }, [dep]);
  return ref;
}

/* ══════════════════════════════════════════════════════════════════════════ */
export default function AdminPage() {
  const [key,    setKey]    = useState('');
  const [authed, setAuthed] = useState(false);
  const [err,    setErr]    = useState('');
  const [busy,   setBusy]   = useState(false);

  useEffect(() => {
    const k = localStorage.getItem('unic_admin_key');
    if (k) { setKey(k); auth(k); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function auth(k) {
    setBusy(true); setErr('');
    const r = await fetch(`/api/admin/stats?key=${encodeURIComponent(k)}`);
    if (r.status === 401) { setErr('Wrong admin key.'); setBusy(false); return; }
    localStorage.setItem('unic_admin_key', k);
    setAuthed(true); setBusy(false);
  }

  if (!authed) return (
    <Shell title="Admin Login">
      <div style={S.center}>
        <div style={S.loginCard}>
          <div style={S.stripe}/>
          <div style={{padding:36}}>
            <div style={S.bigLogo}>UN</div>
            <h2 style={{fontSize:21,fontWeight:800,color:'#111',textAlign:'center',marginBottom:6}}>Admin Access</h2>
            <p style={{fontSize:13,color:'#9ca3af',textAlign:'center',marginBottom:22}}>
              Enter your admin key to continue
            </p>
            <input type="password" placeholder="Admin key"
              value={key} onChange={e=>setKey(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&auth(key)}
              style={S.inp}/>
            {err&&<p style={{color:'#ef4444',fontSize:12,marginTop:6,textAlign:'center'}}>{err}</p>}
            <button disabled={!key||busy} onClick={()=>auth(key)}
              style={{...S.btn('#6C3FF5'),width:'100%',marginTop:14,justifyContent:'center',opacity:(!key||busy)?0.5:1}}>
              {busy?'Checking…':'Access Dashboard →'}
            </button>
            <p style={{fontSize:11,color:'#bbb',textAlign:'center',marginTop:12}}>
              Default key: <code style={{background:'#f3f4f6',padding:'1px 5px',borderRadius:4}}>unic_admin_2024</code>
            </p>
          </div>
        </div>
      </div>
    </Shell>
  );

  return <Dashboard adminKey={key} onLogout={()=>{localStorage.removeItem('unic_admin_key');setAuthed(false);setKey('');}} />;
}

/* ══════════════════════════════════════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════════════════════════════════════ */
function Dashboard({ adminKey, onLogout }) {
  const [tab, setTab] = useState('builder');
  return (
    <Shell title="Admin — UNIC Academic">
      <header style={S.header}>
        <Link href="/" style={{display:'flex',padding:6,color:'#9ca3af',borderRadius:8,border:'1.5px solid #e5e7eb'}}>
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/>
          </svg>
        </Link>
        <div style={S.logo}>UN</div>
        <div>
          <div style={{fontWeight:700,fontSize:14,color:'#111'}}>UNIC Academic</div>
          <div style={{fontSize:11,color:'#9ca3af'}}>Admin Panel</div>
        </div>
        <div style={{marginLeft:'auto',display:'flex',gap:8,alignItems:'center'}}>
          <TabPill label="📊 Data"             active={tab==='data'}    onClick={()=>setTab('data')}/>
          <TabPill label="✏️ Question Builder" active={tab==='builder'} onClick={()=>setTab('builder')}/>
          <button onClick={onLogout} style={{...S.btnOutline,fontSize:12,padding:'6px 14px',marginLeft:8}}>Sign out</button>
        </div>
      </header>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'24px 20px'}}>
        {tab==='data'    && <DataSection    adminKey={adminKey}/>}
        {tab==='builder' && <BuilderSection adminKey={adminKey}/>}
      </div>
    </Shell>
  );
}

function TabPill({label,active,onClick}){
  return(
    <button onClick={onClick} style={{padding:'7px 16px',borderRadius:10,border:`1.5px solid ${active?'transparent':'#e5e7eb'}`,background:active?'#6C3FF5':'#fff',color:active?'#fff':'#6b7280',fontSize:13,fontWeight:700,cursor:'pointer'}}>
      {label}
    </button>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   DATA SECTION
══════════════════════════════════════════════════════════════════════════ */
function DataSection({ adminKey }) {
  const [stats,   setStats]   = useState(null);
  const [tab,     setTab]     = useState('registrations');
  const [rows,    setRows]    = useState([]);
  const [total,   setTotal]   = useState(0);
  const [page,    setPage]    = useState(0);
  const [search,  setSearch]  = useState('');
  const [busy,    setBusy]    = useState(false);
  const [dbMsg,   setDbMsg]   = useState('');

  useEffect(()=>{
    fetch(`/api/admin/stats?key=${adminKey}`).then(r=>r.json()).then(d=>{
      if(d.error&&!d.registrations) setDbMsg(d.error);
      else setStats(d);
    }).catch(()=>{});
  },[adminKey]);

  useEffect(()=>{
    setBusy(true);
    fetch(`/api/admin/${tab}?key=${adminKey}&limit=${PAGE_SIZE}&offset=${page*PAGE_SIZE}`)
      .then(r=>r.json()).then(d=>{
        if(d.error) setDbMsg(d.error);
        setRows(d.rows||[]); setTotal(d.total||0);
      }).catch(()=>{}).finally(()=>setBusy(false));
  },[adminKey,tab,page]);

  const filtered = rows.filter(r=>Object.values(r).some(v=>String(v??'').toLowerCase().includes(search.toLowerCase())));
  const totalPages = Math.ceil(total/PAGE_SIZE);

  function exportCSV(){
    if(!filtered.length) return;
    const keys=Object.keys(filtered[0]);
    const csv=[keys.join(','),...filtered.map(r=>keys.map(k=>`"${String(r[k]??'').replace(/"/g,'""')}"`).join(','))].join('\n');
    const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
    a.download=`${tab}_${new Date().toISOString().slice(0,10)}.csv`; a.click();
  }

  return (
    <>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))',gap:14,marginBottom:24}}>
        {[['👥','Registrations',stats?.registrations??'—'],['✅','Attempts',stats?.attempts??'—'],['🎯','Accuracy',stats?.accuracy??'—'],['📅',"Today's Regs",stats?.todayRegs??'—']].map(([icon,label,val])=>(
          <div key={label} style={S.card}>
            <div style={{fontSize:24,marginBottom:6}}>{icon}</div>
            <div style={{fontSize:26,fontWeight:800,color:'#111'}}>{val}</div>
            <div style={{fontSize:12,color:'#9ca3af',marginTop:2}}>{label}</div>
          </div>
        ))}
      </div>

      <div style={{display:'flex',gap:8,marginBottom:14}}>
        {['registrations','attempts'].map(t=>(
          <button key={t} onClick={()=>{setTab(t);setPage(0);}} style={{padding:'7px 18px',borderRadius:9,fontSize:13,fontWeight:700,cursor:'pointer',textTransform:'capitalize',border:'1.5px solid',borderColor:tab===t?'transparent':'#e5e7eb',background:tab===t?'#6C3FF5':'#fff',color:tab===t?'#fff':'#6b7280'}}>{t}</button>
        ))}
      </div>

      <div style={{...S.card,padding:0,overflow:'hidden'}}>
        <div style={{padding:'12px 16px',borderBottom:'1px solid #f3f4f6',display:'flex',gap:10,alignItems:'center',flexWrap:'wrap'}}>
          <input placeholder="Search…" value={search} onChange={e=>setSearch(e.target.value)} style={{...S.inp,width:200,padding:'7px 12px',fontSize:12}}/>
          <button onClick={exportCSV} style={{...S.btnOutline,fontSize:12,padding:'7px 14px'}}>⬇ CSV</button>
          <span style={{marginLeft:'auto',fontSize:12,color:'#9ca3af'}}>{total} records</span>
        </div>
        {dbMsg&&!stats ? <DbTip/> : busy ? <div style={{padding:40,textAlign:'center',color:'#9ca3af'}}>Loading…</div>
        : !filtered.length ? <div style={{padding:40,textAlign:'center',color:'#9ca3af'}}>No {tab} yet</div>
        : (
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse'}}>
              <thead>
                <tr style={{background:'#f9fafb',borderBottom:'1px solid #e5e7eb'}}>
                  {Object.keys(filtered[0]).map(k=>(
                    <th key={k} style={{textAlign:'left',padding:'9px 14px',fontSize:11,fontWeight:700,color:'#9ca3af',textTransform:'uppercase',letterSpacing:'.05em',whiteSpace:'nowrap'}}>{k}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((row,i)=>(
                  <tr key={i} style={{borderBottom:'1px solid #f9fafb'}}>
                    {Object.entries(row).map(([k,v])=>(
                      <td key={k} style={{padding:'10px 14px',fontSize:12,color:'#374151',maxWidth:200,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                        {k==='is_correct'
                          ? <span style={{padding:'2px 8px',borderRadius:20,fontSize:11,fontWeight:600,background:v?'#dcfce7':'#fee2e2',color:v?'#15803d':'#b91c1c'}}>{v?'✓ Correct':'✗ Wrong'}</span>
                          : k==='subject' ? <span style={{padding:'2px 8px',borderRadius:20,fontSize:11,fontWeight:600,background:'#dbeafe',color:'#1d4ed8'}}>{v}</span>
                          : typeof v==='object' ? JSON.stringify(v) : String(v??'')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {totalPages>1&&(
          <div style={{padding:'12px 16px',borderTop:'1px solid #f3f4f6',display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:12,color:'#9ca3af'}}>
            <span>Page {page+1} of {totalPages}</span>
            <div style={{display:'flex',gap:6}}>
              <button disabled={page===0} onClick={()=>setPage(p=>p-1)} style={{...S.btnOutline,fontSize:12,padding:'5px 12px',opacity:page===0?0.4:1}}>← Prev</button>
              <button disabled={page>=totalPages-1} onClick={()=>setPage(p=>p+1)} style={{...S.btnOutline,fontSize:12,padding:'5px 12px',opacity:page>=totalPages-1?0.4:1}}>Next →</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function DbTip(){
  return(
    <div style={{padding:36,textAlign:'center'}}>
      <div style={{fontSize:36,marginBottom:10}}>🗄️</div>
      <p style={{fontWeight:600,color:'#374151',marginBottom:8}}>Hasura not connected</p>
      <div style={{background:'#1e1e2e',borderRadius:12,padding:'16px 20px',textAlign:'left',maxWidth:500,margin:'0 auto',fontSize:12,fontFamily:'monospace',color:'#cdd6f4',lineHeight:1.9}}>
        <span style={{color:'#6c7086'}}># Add these to Vercel → Settings → Env Vars:{'\n'}</span>
        HASURA_GRAPHQL_URL=https://…hasura.app/v1/graphql{'\n'}
        HASURA_ADMIN_SECRET=your-secret{'\n'}
        ADMIN_KEY=unic_admin_2024{'\n\n'}
        <span style={{color:'#6c7086'}}># Then run hasura/migrations/001_init.sql{'\n'}</span>
        <span style={{color:'#6c7086'}}># Track all 3 tables in Hasura Console</span>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   BUILDER SECTION  — 3-column layout:
   [Subject tree] | [Chapter editor] | [Live Preview]
══════════════════════════════════════════════════════════════════════════ */
function BuilderSection({ adminKey }) {
  const [subjects,    setSubjects]    = useState([...BUILTIN]);
  const [activeCode,  setActiveCode]  = useState('PH');
  const [data,        setData]        = useState(null);   // full subject doc
  const [loading,     setLoading]     = useState(false);
  const [collapsed,   setCollapsed]   = useState({});
  const [activeUId,   setActiveUId]   = useState(null);
  const [activeCId,   setActiveCId]   = useState(null);
  const [previewQ,    setPreviewQ]    = useState(null);   // question being previewed
  const [previewConcept, setPreviewConcept] = useState(false);
  const [openQId,     setOpenQId]     = useState(null);
  const [dirty,       setDirty]       = useState(false);
  const [status,      setStatus]      = useState({msg:'',type:''});
  const [jsonModal,   setJsonModal]   = useState(false);

  const mark = () => { setDirty(true); setStatus({msg:'Unsaved changes',type:'warn'}); };
  function setD(fn){ setData(prev=>{ const d=JSON.parse(JSON.stringify(prev)); fn(d); return d; }); mark(); }
  function getUnit(id){ return data?.units?.find(u=>u.id===id); }
  function getCh(uid,cid){ return getUnit(uid)?.chapters?.find(c=>c.id===cid); }
  const chap = activeUId&&activeCId ? getCh(activeUId,activeCId) : null;
  function findCh(d){ return d.units?.find(u=>u.id===activeUId)?.chapters?.find(c=>c.id===activeCId); }

  // Load subject
  useEffect(()=>{
    setLoading(true); setActiveUId(null); setActiveCId(null); setOpenQId(null); setPreviewQ(null); setPreviewConcept(false);
    fetch(`/api/content?code=${activeCode}`).then(r=>r.json()).then(j=>{
      if(j?.data?.units) { setData(j.data); setLoading(false); return; }
      throw new Error('not in db');
    }).catch(()=>{
      const file = STATIC_MAP[activeCode];
      if(!file){ const m=subjects.find(s=>s.code===activeCode)||{subject:activeCode,color:'#6C3FF5'}; setData({subject:m.subject,code:activeCode,color:m.color,units:[]}); setLoading(false); return; }
      import(`../../data/${file}.json`).then(m=>{ setData(m.default||m); setLoading(false); }).catch(()=>{ const m=subjects.find(s=>s.code===activeCode)||{subject:activeCode,color:'#6C3FF5'}; setData({subject:m.subject,code:activeCode,color:m.color,units:[]}); setLoading(false); });
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[activeCode]);

  // ── Unit / Chapter mutations ───────────────────────────────────────────────
  function addUnit(){ const t=prompt('Unit title (e.g. "Unit 1: Mechanics"):'); if(!t?.trim()) return; setD(d=>d.units.push({id:uid('u'),title:t.trim(),chapters:[]})); }
  function renameUnit(id){ const u=getUnit(id); if(!u) return; const t=prompt('Rename unit:',u.title); if(!t?.trim()) return; setD(d=>{ const u=d.units.find(x=>x.id===id); if(u) u.title=t.trim(); }); }
  function deleteUnit(id){ if(!confirm('Delete unit + all chapters?')) return; setD(d=>{ d.units=d.units.filter(u=>u.id!==id); }); if(activeUId===id){ setActiveUId(null); setActiveCId(null); } }
  function addChapter(uid){ const t=prompt('Chapter title:'); if(!t?.trim()) return; const id=uid('c'); setD(d=>{ const u=d.units.find(x=>x.id===uid); u?.chapters.push({id,title:t.trim(),concept:{title:t.trim(),latex:true,image:null,body:[],formulas:[]},questions:[]}); }); setActiveUId(uid); setActiveCId(id); }
  function deleteChapter(uid,cid){ if(!confirm('Delete chapter + questions?')) return; setD(d=>{ const u=d.units.find(x=>x.id===uid); if(u) u.chapters=u.chapters.filter(c=>c.id!==cid); }); if(activeCId===cid){ setActiveCId(null); setOpenQId(null); setPreviewQ(null); } }

  // ── Concept ────────────────────────────────────────────────────────────────
  function setConField(path,val){ setD(d=>{ const c=findCh(d); if(!c) return; const parts=path.split('.'); let o=c; parts.slice(0,-1).forEach(p=>o=o[p]); o[parts[parts.length-1]]=val; }); }
  function addPara(){ setD(d=>{ findCh(d)?.concept.body.push(''); }); }
  function setPara(i,v){ setD(d=>{ const c=findCh(d); if(c) c.concept.body[i]=v; }); }
  function delPara(i){ setD(d=>{ findCh(d)?.concept.body.splice(i,1); }); }
  function addFormula(){ setD(d=>{ findCh(d)?.concept.formulas.push(''); }); }
  function setFormula(i,v){ setD(d=>{ const c=findCh(d); if(c) c.concept.formulas[i]=v; }); }
  function delFormula(i){ setD(d=>{ findCh(d)?.concept.formulas.splice(i,1); }); }

  // ── Questions ──────────────────────────────────────────────────────────────
  function addQ(type){ const id=uid('q'); const q=type==='NAT'?{id,type,latex:false,image:null,question:'',answer:0,tolerance:0,unit:'',explanation:''}:{id,type,latex:false,image:null,question:'',options:['','','',''],answer:[],explanation:''}; setD(d=>{ findCh(d)?.questions.push(q); }); setOpenQId(id); setPreviewQ(id); }
  function delQ(qid){ if(!confirm('Delete this question?')) return; setD(d=>{ const c=findCh(d); if(c) c.questions=c.questions.filter(q=>q.id!==qid); }); if(openQId===qid) setOpenQId(null); if(previewQ===qid) setPreviewQ(null); }
  function setQ(qid,field,val){ setD(d=>{ const q=findCh(d)?.questions?.find(x=>x.id===qid); if(q) q[field]=val; }); }
  function setOpt(qid,i,val){ setD(d=>{ const q=findCh(d)?.questions?.find(x=>x.id===qid); if(q) q.options[i]=val; }); }
  function toggleAns(qid,i,checked,type){ setD(d=>{ const q=findCh(d)?.questions?.find(x=>x.id===qid); if(!q) return; if(type==='MCQ') q.answer=checked?[i]:[]; else { if(checked&&!q.answer.includes(i)) q.answer.push(i); else q.answer=q.answer.filter(a=>a!==i); } }); }
  function addOpt(qid){ setD(d=>{ const q=findCh(d)?.questions?.find(x=>x.id===qid); if(q&&(q.options?.length||0)<6) q.options.push(''); }); }
  function delOpt(qid,i){ setD(d=>{ const q=findCh(d)?.questions?.find(x=>x.id===qid); if(!q) return; q.options.splice(i,1); q.answer=(q.answer||[]).filter(a=>a!==i).map(a=>a>i?a-1:a); }); }

  // ── Image upload ───────────────────────────────────────────────────────────
  function uploadImg(target,qid){
    const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*';
    inp.onchange=async()=>{
      const file=inp.files[0]; if(!file) return;
      const reader=new FileReader();
      reader.onload=async e=>{
        setStatus({msg:'Uploading…',type:''});
        try{
          const r=await fetch('/api/upload-image',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:adminKey,dataUri:e.target.result,filename:file.name})});
          const j=await r.json(); if(j.error) throw new Error(j.error);
          if(target==='concept') setD(d=>{ findCh(d).concept.image=j.url; });
          else setQ(qid,'image',j.url);
          setStatus({msg:'✓ Image uploaded',type:'success'});
        }catch(e){ setStatus({msg:'✗ '+e.message,type:'error'}); }
      };
      reader.readAsDataURL(file);
    };
    inp.click();
  }
  function removeImg(target,qid){
    if(target==='concept') setD(d=>{ findCh(d).concept.image=null; });
    else setQ(qid,'image',null);
  }

  // ── Save / Download ────────────────────────────────────────────────────────
  async function save(){
    if(!data) return; setStatus({msg:'Saving…',type:''});
    const r=await fetch(`/api/content?key=${adminKey}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:adminKey,code:data.code,subject:data.subject,color:data.color,data})});
    const j=await r.json();
    if(j.success){ setDirty(false); setStatus({msg:'✓ Saved to database',type:'success'}); }
    else if(j.configured===false) setStatus({msg:'⚠ Hasura not configured — use Download JSON',type:'error'});
    else setStatus({msg:'✗ '+(j.error||'failed'),type:'error'});
  }
  function download(){ if(!data) return; const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})); a.download=`${data.code?.toLowerCase()||'subject'}.json`; a.click(); }

  const subjectColor = subjects.find(s=>s.code===activeCode)?.color||'#6C3FF5';
  const previewQuestion = chap?.questions?.find(q=>q.id===previewQ)||null;

  return (
    <>
      {/* JSON preview modal */}
      {jsonModal&&(
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.6)',backdropFilter:'blur(3px)',zIndex:300,display:'flex',alignItems:'center',justifyContent:'center',padding:20}} onClick={e=>e.target===e.currentTarget&&setJsonModal(false)}>
          <div style={{background:'#1e1e2e',borderRadius:18,width:'100%',maxWidth:740,maxHeight:'82vh',display:'flex',flexDirection:'column',overflow:'hidden',boxShadow:'0 20px 60px rgba(0,0,0,.4)'}}>
            <div style={{display:'flex',alignItems:'center',padding:'14px 20px',borderBottom:'1px solid #313244'}}>
              <span style={{color:'#cdd6f4',fontWeight:700,fontSize:13,flex:1}}>{data?.subject} — Full JSON</span>
              <button onClick={()=>{navigator.clipboard?.writeText(JSON.stringify(data,null,2));setStatus({msg:'✓ Copied',type:'success'});}} style={{background:'#313244',border:'none',color:'#cdd6f4',borderRadius:8,padding:'5px 12px',fontSize:12,cursor:'pointer',marginRight:8}}>Copy</button>
              <button onClick={()=>setJsonModal(false)} style={{background:'none',border:'none',color:'#9399b2',fontSize:22,cursor:'pointer',lineHeight:1}}>×</button>
            </div>
            <div style={{flex:1,overflow:'auto',padding:'16px 20px'}}>
              <pre style={{fontFamily:'monospace',fontSize:12,color:'#cdd6f4',lineHeight:1.7,whiteSpace:'pre-wrap',wordBreak:'break-word'}}>{JSON.stringify(data,null,2)}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Subject pills */}
      <div style={{...S.card,marginBottom:16,display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
        <span style={S.label}>Subject</span>
        <div style={{display:'flex',flexWrap:'wrap',gap:8,flex:1}}>
          {subjects.map(s=>{
            const act=s.code===activeCode;
            return <button key={s.code} onClick={()=>setActiveCode(s.code)} style={{padding:'6px 16px',borderRadius:9,border:`1.5px solid ${act?'transparent':s.color+'44'}`,background:act?s.color:s.color+'14',color:act?'#fff':s.color,fontSize:12.5,fontWeight:700,cursor:'pointer'}}>{s.subject} ({s.code})</button>;
          })}
        </div>
        <button onClick={()=>{const name=prompt('Subject name:');if(!name?.trim()) return;const code=prompt('Code (e.g. CS):')?.trim().toUpperCase();if(!code) return;const color=prompt('Hex color:','#9333EA')||'#9333EA';setSubjects(s=>[...s,{code,subject:name.trim(),color}]);setActiveCode(code);}} style={{...S.btnOutline,fontSize:12,padding:'6px 12px'}}>+ New</button>
      </div>

      {/* 3-column layout: Tree | Editor | Preview */}
      <div style={{display:'grid',gridTemplateColumns:'230px 1fr 360px',gap:16,alignItems:'start'}}>

        {/* ── COL 1: Unit/Chapter tree ── */}
        <div style={{...S.card,padding:0}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 14px',borderBottom:'1px solid #f3f4f6'}}>
            <span style={S.label}>Structure</span>
          </div>
          <div style={{maxHeight:620,overflowY:'auto',padding:'6px 0'}}>
            {loading?<div style={{padding:16,fontSize:13,color:'#9ca3af'}}>Loading…</div>
            :data?.units?.map(unit=>(
              <div key={unit.id}>
                <div style={{display:'flex',alignItems:'center',padding:'7px 10px',gap:4}}>
                  <button onClick={()=>setCollapsed(c=>({...c,[unit.id]:!c[unit.id]}))} style={{flex:1,background:'none',border:'none',cursor:'pointer',textAlign:'left',fontSize:12,fontWeight:600,color:'#374151',display:'flex',alignItems:'center',gap:5}}>
                    <svg width="11" height="11" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{transform:collapsed[unit.id]?'rotate(-90deg)':'none',transition:'transform .15s',flexShrink:0}}>
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{unit.title}</span>
                  </button>
                  <IBtn title="Rename" onClick={()=>renameUnit(unit.id)}>✏️</IBtn>
                  <IBtn title="Delete unit" danger onClick={()=>deleteUnit(unit.id)}>🗑</IBtn>
                </div>
                {!collapsed[unit.id]&&(
                  <div style={{marginLeft:12,paddingLeft:10,borderLeft:'2px solid #f3f4f6'}}>
                    {unit.chapters?.map(ch=>{
                      const active=ch.id===activeCId;
                      const qn=ch.questions?.length||0;
                      return(
                        <div key={ch.id} style={{display:'flex',alignItems:'center',padding:'6px 8px',borderRadius:8,marginBottom:2,background:active?subjectColor:'transparent',gap:4}}>
                          <button onClick={()=>{setActiveUId(unit.id);setActiveCId(ch.id);setOpenQId(null);setPreviewQ(null);setPreviewConcept(false);}} style={{flex:1,background:'none',border:'none',cursor:'pointer',textAlign:'left',fontSize:12,color:active?'#fff':'#6b7280'}}>
                            <span style={{overflow:'hidden',textOverflow:'ellipsis',display:'block',whiteSpace:'nowrap'}}>{ch.title}</span>
                            <span style={{fontSize:10,background:active?'rgba(255,255,255,.25)':'#f3f4f6',color:active?'rgba(255,255,255,.8)':'#9ca3af',borderRadius:8,padding:'0 5px',marginTop:2,display:'inline-block'}}>{qn}q</span>
                          </button>
                          <IBtn title="Delete chapter" danger onClick={()=>deleteChapter(unit.id,ch.id)} color={active?'rgba(255,255,255,.7)':undefined}>✕</IBtn>
                        </div>
                      );
                    })}
                    <DashBtn onClick={()=>addChapter(unit.id)}>+ Chapter</DashBtn>
                  </div>
                )}
              </div>
            ))}
            <DashBtn onClick={addUnit} style={{margin:'6px 10px',width:'calc(100% - 20px)'}}>+ Add Unit</DashBtn>
          </div>
        </div>

        {/* ── COL 2: Chapter editor ── */}
        <div style={{...S.card,padding:0}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 16px',borderBottom:'1px solid #f3f4f6'}}>
            <span style={S.label}>{chap?chap.title:'Editor'}</span>
            <button onClick={()=>setJsonModal(true)} style={{...S.btnOutline,fontSize:11,padding:'4px 10px'}}>{'{ }'} JSON</button>
          </div>

          {!chap?(
            <div style={{padding:48,textAlign:'center',color:'#9ca3af'}}>
              <div style={{fontSize:36,marginBottom:10}}>👈</div>
              <p style={{fontSize:13}}>Select or create a chapter</p>
            </div>
          ):(
            <div style={{maxHeight:640,overflowY:'auto'}}>

              {/* Chapter title */}
              <Sec title="Chapter Title">
                <input value={chap.title} onChange={e=>setD(d=>{ findCh(d).title=e.target.value; })} style={S.inp}/>
              </Sec>

              {/* Concept */}
              <Sec title="💡 Concept / Theory"
                action={<button onClick={()=>{setPreviewConcept(true);setPreviewQ(null);}} style={{...S.btnOutline,fontSize:11,padding:'3px 10px'}}>👁 Preview</button>}>
                <F label="Title"><input value={chap.concept?.title||''} onChange={e=>setConField('concept.title',e.target.value)} style={S.inp}/></F>
                <F label="">
                  <label style={{display:'flex',alignItems:'center',gap:8,fontSize:13,color:'#374151',cursor:'pointer'}}>
                    <input type="checkbox" checked={!!chap.concept?.latex} onChange={e=>setConField('concept.latex',e.target.checked)} style={{width:16,height:16}}/>
                    Enable LaTeX ($…$ and $$…$$)
                  </label>
                </F>
                <F label="Image">
                  {chap.concept?.image
                    ?<div style={{position:'relative',display:'inline-block',marginTop:4}}>
                       <img src={chap.concept.image} alt="" style={{maxHeight:120,borderRadius:10,border:'1px solid #e5e7eb'}}/>
                       <button onClick={()=>removeImg('concept',null)} style={{position:'absolute',top:4,right:4,width:22,height:22,borderRadius:'50%',background:'#ef4444',border:'none',color:'#fff',fontSize:14,cursor:'pointer',lineHeight:1}}>×</button>
                     </div>
                    :<UploadBtn onClick={()=>uploadImg('concept',null)}/>
                  }
                </F>
                <F label="Body Paragraphs">
                  {(chap.concept?.body||[]).map((p,i)=>(
                    <div key={i} style={{display:'flex',gap:6,marginBottom:8,alignItems:'flex-start'}}>
                      <textarea rows={2} value={p} onChange={e=>setPara(i,e.target.value)} placeholder="Use **bold** and $LaTeX$…" style={{...S.inp,flex:1,resize:'vertical',fontSize:12}}/>
                      <IBtn danger onClick={()=>delPara(i)}>✕</IBtn>
                    </div>
                  ))}
                  <DashBtn onClick={addPara}>+ Add Paragraph</DashBtn>
                </F>
                <F label="Key Formulas">
                  {(chap.concept?.formulas||[]).map((f,i)=>(
                    <div key={i} style={{display:'flex',gap:6,marginBottom:8,alignItems:'center'}}>
                      <input value={f} onChange={e=>setFormula(i,e.target.value)} placeholder="$F = ma$" style={{...S.inp,flex:1,fontSize:12}}/>
                      <IBtn danger onClick={()=>delFormula(i)}>✕</IBtn>
                    </div>
                  ))}
                  <DashBtn onClick={addFormula}>+ Add Formula</DashBtn>
                </F>
              </Sec>

              {/* Questions */}
              <Sec title={`❓ Questions (${chap.questions?.length||0})`}
                action={<div style={{display:'flex',gap:5}}>
                  {['MCQ','MSQ','NAT'].map(t=>(
                    <button key={t} onClick={()=>addQ(t)} style={{padding:'3px 9px',borderRadius:7,border:`1.5px solid ${QTYPE_COLOR[t]}44`,background:QTYPE_COLOR[t]+'14',color:QTYPE_COLOR[t],fontSize:11,fontWeight:700,cursor:'pointer'}}>+{t}</button>
                  ))}
                </div>}>

                {!(chap.questions?.length)&&(
                  <div style={{textAlign:'center',padding:'20px 0',color:'#9ca3af',fontSize:13}}>No questions yet — add one above</div>
                )}

                {(chap.questions||[]).map((q)=>{
                  const isOpen=openQId===q.id;
                  const isPreview=previewQ===q.id;
                  const summary=(q.question||'(empty)').replace(/\$/g,'').slice(0,55);
                  return(
                    <div key={q.id} style={{border:`1.5px solid ${isPreview?subjectColor:'#e5e7eb'}`,borderRadius:12,marginBottom:10,overflow:'hidden',transition:'border-color .15s'}}>
                      {/* Question row header */}
                      <div style={{display:'flex',alignItems:'center',gap:8,padding:'10px 12px',background:isOpen?'#f9fafb':'#fff'}}>
                        <span style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:20,color:'#fff',background:QTYPE_COLOR[q.type],flexShrink:0}}>{q.type}</span>
                        <span style={{flex:1,fontSize:12,color:'#374151',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',cursor:'pointer'}} onClick={()=>setOpenQId(isOpen?null:q.id)}>{summary||'(empty)'}</span>
                        {/* Preview toggle */}
                        <button
                          onClick={()=>{setPreviewQ(isPreview?null:q.id);setPreviewConcept(false);}}
                          title="Preview this question"
                          style={{background:isPreview?subjectColor:'#f3f4f6',border:'none',borderRadius:7,padding:'4px 8px',fontSize:11,fontWeight:700,color:isPreview?'#fff':'#6b7280',cursor:'pointer',flexShrink:0}}>
                          👁 {isPreview?'Previewing':'Preview'}
                        </button>
                        <button onClick={()=>setOpenQId(isOpen?null:q.id)} style={{background:'none',border:'none',cursor:'pointer',color:'#9ca3af',padding:4}}>
                          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{transform:isOpen?'rotate(180deg)':'none',transition:'transform .2s'}}>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/>
                          </svg>
                        </button>
                        <IBtn danger onClick={()=>delQ(q.id)} title="Delete question">🗑</IBtn>
                      </div>

                      {/* Question editor body */}
                      {isOpen&&(
                        <div style={{padding:'12px 14px',borderTop:'1px solid #f3f4f6'}}>
                          <F label="Question Text">
                            <textarea rows={3} value={q.question} onChange={e=>setQ(q.id,'question',e.target.value)} placeholder="E.g. Find $a$ when $F=10$ N and $m=2$ kg." style={{...S.inp,resize:'vertical',fontSize:13}}/>
                            <p style={{fontSize:10.5,color:'#9ca3af',marginTop:3}}>Use $…$ for inline LaTeX, $$…$$ for display math, **text** for bold</p>
                          </F>
                          <F label="">
                            <label style={{display:'flex',alignItems:'center',gap:8,fontSize:13,cursor:'pointer',color:'#374151'}}>
                              <input type="checkbox" checked={!!q.latex} onChange={e=>setQ(q.id,'latex',e.target.checked)} style={{width:16,height:16}}/>
                              Enable LaTeX rendering
                            </label>
                          </F>
                          <F label="Question Image">
                            {q.image
                              ?<div style={{position:'relative',display:'inline-block',marginTop:4}}>
                                 <img src={q.image} alt="" style={{maxHeight:110,borderRadius:10,border:'1px solid #e5e7eb'}}/>
                                 <button onClick={()=>removeImg('question',q.id)} style={{position:'absolute',top:4,right:4,width:22,height:22,borderRadius:'50%',background:'#ef4444',border:'none',color:'#fff',fontSize:14,cursor:'pointer',lineHeight:1}}>×</button>
                               </div>
                              :<UploadBtn onClick={()=>uploadImg('question',q.id)}/>
                            }
                          </F>

                          {q.type!=='NAT'&&(
                            <F label={q.type==='MCQ'?'Options — tick the ONE correct answer':'Options — tick ALL correct answers'}>
                              {(q.options||[]).map((opt,i)=>(
                                <div key={i} style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                                  <span style={{width:22,height:22,borderRadius:6,background:'#f3f4f6',color:'#6b7280',fontSize:10.5,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{LABELS[i]}</span>
                                  <input value={opt} onChange={e=>setOpt(q.id,i,e.target.value)} placeholder={`Option ${LABELS[i]}`} style={{...S.inp,flex:1,fontSize:13}}/>
                                  <input type={q.type==='MCQ'?'radio':'checkbox'} name={`ans-${q.id}`} checked={(q.answer||[]).includes(i)} onChange={e=>toggleAns(q.id,i,e.target.checked,q.type)} style={{width:16,height:16,cursor:'pointer',flexShrink:0}} title="Mark correct"/>
                                  <IBtn danger onClick={()=>delOpt(q.id,i)}>✕</IBtn>
                                </div>
                              ))}
                              {(q.options?.length||0)<6&&<DashBtn onClick={()=>addOpt(q.id)}>+ Add Option</DashBtn>}
                            </F>
                          )}

                          {q.type==='NAT'&&(
                            <>
                              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
                                <F label="Correct Answer"><input type="number" step="any" value={q.answer??0} onChange={e=>setQ(q.id,'answer',parseFloat(e.target.value)||0)} style={S.inp}/></F>
                                <F label="Tolerance (±)"><input type="number" step="any" value={q.tolerance??0} onChange={e=>setQ(q.id,'tolerance',parseFloat(e.target.value)||0)} style={S.inp}/></F>
                              </div>
                              <F label="Unit (optional)"><input value={q.unit||''} onChange={e=>setQ(q.id,'unit',e.target.value)} placeholder="m/s²" style={S.inp}/></F>
                            </>
                          )}

                          <F label="Explanation">
                            <textarea rows={2} value={q.explanation||''} onChange={e=>setQ(q.id,'explanation',e.target.value)} placeholder="Why this answer is correct…" style={{...S.inp,resize:'vertical',fontSize:13}}/>
                          </F>
                        </div>
                      )}
                    </div>
                  );
                })}
              </Sec>
            </div>
          )}

          {/* Save toolbar */}
          <div style={{padding:'12px 16px',borderTop:'1px solid #f3f4f6',display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
            <button onClick={save} style={S.btn('#6C3FF5')}>💾 Save to DB</button>
            <button onClick={download} style={S.btnOutline}>⬇ Download JSON</button>
            <span style={{fontSize:12,fontWeight:600,color:status.type==='success'?'#16a34a':status.type==='error'?'#dc2626':'#f59e0b',marginLeft:4}}>{status.msg}</span>
            {dirty&&<span style={{marginLeft:'auto',fontSize:11,color:'#f59e0b',fontWeight:700}}>● unsaved</span>}
          </div>
        </div>

        {/* ── COL 3: Live Preview ── */}
        <div style={{...S.card,padding:0,position:'sticky',top:24}}>
          <div style={{padding:'12px 16px',borderBottom:'1px solid #f3f4f6',display:'flex',alignItems:'center',gap:8}}>
            <span style={S.label}>👁 Live Preview</span>
            {(previewConcept||previewQuestion)&&(
              <button onClick={()=>{setPreviewQ(null);setPreviewConcept(false);}} style={{marginLeft:'auto',background:'none',border:'none',fontSize:11,color:'#9ca3af',cursor:'pointer'}}>✕ Clear</button>
            )}
          </div>
          <div style={{maxHeight:680,overflowY:'auto',padding:'14px 16px'}}>
            {!chap&&!previewConcept&&!previewQuestion&&(
              <div style={{textAlign:'center',padding:'40px 0',color:'#9ca3af'}}>
                <div style={{fontSize:32,marginBottom:8}}>👁</div>
                <p style={{fontSize:13}}>Select a chapter, then click <strong>Preview</strong> on a question or concept to see how it looks to students.</p>
              </div>
            )}

            {/* Concept preview */}
            {previewConcept&&chap?.concept&&(
              <ConceptPreview concept={chap.concept} color={subjectColor}/>
            )}

            {/* Question preview */}
            {previewQuestion&&(
              <QuestionPreview q={previewQuestion} color={subjectColor}/>
            )}

            {/* If chapter is selected but nothing pinned, show mini list */}
            {chap&&!previewConcept&&!previewQuestion&&(
              <div>
                <p style={{fontSize:11,color:'#9ca3af',fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',marginBottom:10}}>Chapter contents</p>
                {/* Concept mini card */}
                {chap.concept&&(
                  <button onClick={()=>{setPreviewConcept(true);setPreviewQ(null);}} style={{width:'100%',textAlign:'left',padding:'10px 12px',borderRadius:10,border:'1.5px solid #e5e7eb',background:'#f9fafb',cursor:'pointer',marginBottom:8,display:'flex',alignItems:'center',gap:8}}>
                    <span style={{fontSize:16}}>💡</span>
                    <div>
                      <div style={{fontSize:12,fontWeight:700,color:'#374151'}}>Concept: {chap.concept.title}</div>
                      <div style={{fontSize:11,color:'#9ca3af',marginTop:1}}>{chap.concept.body?.length||0} paragraphs · {chap.concept.formulas?.length||0} formulas{chap.concept.image?' · 🖼':''}</div>
                    </div>
                    <span style={{marginLeft:'auto',fontSize:11,color:subjectColor,fontWeight:700}}>Preview →</span>
                  </button>
                )}
                {/* Question mini cards */}
                {(chap.questions||[]).map(q=>(
                  <button key={q.id} onClick={()=>{setPreviewQ(q.id);setPreviewConcept(false);}} style={{width:'100%',textAlign:'left',padding:'10px 12px',borderRadius:10,border:'1.5px solid #e5e7eb',background:'#fff',cursor:'pointer',marginBottom:8,display:'flex',alignItems:'center',gap:8}}>
                    <span style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:20,color:'#fff',background:QTYPE_COLOR[q.type],flexShrink:0}}>{q.type}</span>
                    <span style={{fontSize:12,color:'#374151',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{(q.question||'(empty)').replace(/\$/g,'').slice(0,45)}</span>
                    {q.image&&<span style={{fontSize:13}}>🖼</span>}
                    <span style={{fontSize:11,color:subjectColor,fontWeight:700,flexShrink:0}}>Preview →</span>
                  </button>
                ))}
                {!(chap.questions?.length)&&<p style={{fontSize:12,color:'#9ca3af',textAlign:'center',padding:'12px 0'}}>No questions yet</p>}
              </div>
            )}
          </div>
        </div>

      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   CONCEPT PREVIEW — renders exactly like the student-facing ConceptCard
══════════════════════════════════════════════════════════════════════════ */
function ConceptPreview({ concept, color }) {
  const ref = useLatex(JSON.stringify(concept));
  return (
    <div ref={ref}>
      <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
        <div style={{width:32,height:32,borderRadius:9,background:color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:15,flexShrink:0}}>💡</div>
        <div>
          <div style={{fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'.08em',color,opacity:.85}}>Concept</div>
          <div style={{fontSize:14,fontWeight:700,color:'#111'}}>{concept.title}</div>
        </div>
      </div>

      {concept.image&&<img src={concept.image} alt={concept.title} style={{width:'100%',borderRadius:10,border:'1px solid #f0f0f0',marginBottom:14}}/>}

      {(concept.body||[]).map((para,i)=>(
        <p key={i} style={{fontSize:13,lineHeight:1.85,color:'#374151',marginBottom:12}} dangerouslySetInnerHTML={{__html:bold(para)}}/>
      ))}

      {!!(concept.formulas||[]).length&&(
        <div style={{marginTop:12,padding:'12px 14px',borderRadius:10,background:'#f9fafb',border:'1px solid #f0f0f0'}}>
          <div style={{fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'#9ca3af',marginBottom:8}}>Key Formulas</div>
          {concept.formulas.map((f,i)=>(
            <span key={i} style={{display:'inline-block',background:'#fff',border:'1px solid #e5e7eb',borderRadius:7,padding:'5px 10px',margin:'0 5px 5px 0',fontSize:12.5,color:'#1f2937'}}>{f}</span>
          ))}
        </div>
      )}

      {!concept.body?.length&&!concept.formulas?.length&&!concept.image&&(
        <p style={{fontSize:12,color:'#9ca3af',fontStyle:'italic'}}>No content yet — add paragraphs or formulas in the editor.</p>
      )}

      <div style={{marginTop:14,padding:'8px 12px',background:'#f0f9ff',borderRadius:8,border:'1px solid #bae6fd'}}>
        <p style={{fontSize:11,color:'#0369a1',fontWeight:600}}>ℹ This is how students see the concept card (LaTeX renders in-app with KaTeX).</p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   QUESTION PREVIEW — renders exactly like the student-facing QCard
   Shows: type badge · question text · image · all options with correct
   highlighting · explanation · NAT answer box
══════════════════════════════════════════════════════════════════════════ */
function QuestionPreview({ q, color }) {
  const [selected, setSelected] = useState([]);
  const [revealed, setRevealed] = useState(false);
  const ref = useLatex(JSON.stringify(q)+revealed);

  // Reset when question changes
  useEffect(()=>{ setSelected([]); setRevealed(false); },[q.id]);

  function toggleOpt(i){
    if(revealed) return;
    if(q.type==='MCQ') setSelected([i]);
    else setSelected(prev=>prev.includes(i)?prev.filter(x=>x!==i):[...prev,i]);
  }

  function optState(i){
    if(!revealed) return selected.includes(i)?'selected':'idle';
    const correct=(q.answer||[]).includes(i);
    const isSel=selected.includes(i);
    if(correct&&isSel) return 'correct';
    if(correct&&!isSel) return 'missed';
    if(!correct&&isSel) return 'wrong';
    return 'idle';
  }

  const isRight = revealed&&(() => {
    if(q.type==='NAT') return false; // NAT doesn't use selected[] for preview
    const a=[...selected].sort((a,b)=>a-b);
    const b=[...(q.answer||[])].sort((a,b)=>a-b);
    return JSON.stringify(a)===JSON.stringify(b);
  })();

  const optStyles = {
    idle:    {border:'2px solid #e5e7eb',bg:'#fff',labelBg:'#f3f4f6',labelColor:'#6b7280'},
    selected:{border:`2px solid ${color}`,bg:color+'15',labelBg:color,labelColor:'#fff'},
    correct: {border:'2px solid #16a34a',bg:'#f0fdf4',labelBg:'#16a34a',labelColor:'#fff'},
    missed:  {border:'2px solid #86efac',bg:'#f0fdf4',labelBg:'#22c55e',labelColor:'#fff',opacity:.8},
    wrong:   {border:'2px solid #ef4444',bg:'#fef2f2',labelBg:'#ef4444',labelColor:'#fff'},
  };

  const hasAnswer = q.type==='NAT' ? true : selected.length>0;

  return (
    <div ref={ref}>
      {/* Type + question number header */}
      <div style={{display:'flex',alignItems:'center',gap:8,padding:'10px 14px',background:color+'12',borderRadius:'12px 12px 0 0',border:`1px solid ${color}22`,borderBottom:'none'}}>
        <span style={{fontSize:10,fontWeight:700,padding:'2px 9px',borderRadius:20,color:'#fff',background:color}}>{q.type}</span>
        {q.type==='MSQ'&&<span style={{fontSize:11,color:'#9ca3af'}}>Select all correct answers</span>}
        {q.type==='NAT'&&<span style={{fontSize:11,color:'#9ca3af'}}>Numerical answer type</span>}
        <span style={{marginLeft:'auto',fontSize:11,color:'#c4c4c4',fontWeight:600}}>Preview</span>
      </div>

      <div style={{border:`1px solid ${color}22`,borderRadius:'0 0 12px 12px',overflow:'hidden',marginBottom:12}}>
        {/* Question text */}
        <div style={{padding:'16px 16px 12px',borderBottom:'1px solid #f3f4f6'}}>
          <p style={{fontSize:14,color:'#111',lineHeight:1.7,fontWeight:500,margin:0}} dangerouslySetInnerHTML={{__html:bold(q.question||'(no question text yet)')}}/>
          {q.image&&(
            <div style={{marginTop:12}}>
              <img src={q.image} alt="Question diagram" style={{width:'100%',maxHeight:240,objectFit:'contain',borderRadius:10,border:'1px solid #f0f0f0',background:'#fafafa'}}/>
            </div>
          )}
        </div>

        {/* Options (MCQ / MSQ) */}
        {q.type!=='NAT'&&(
          <div style={{padding:'12px 14px',display:'flex',flexDirection:'column',gap:8}}>
            {(q.options||[]).length===0&&(
              <p style={{fontSize:12,color:'#9ca3af',fontStyle:'italic',textAlign:'center',padding:'8px 0'}}>No options yet — add them in the editor.</p>
            )}
            {(q.options||[]).map((opt,i)=>{
              const st=optState(i);
              const ost=optStyles[st]||optStyles.idle;
              const labelTxt=st==='correct'||st==='missed'?'✓':st==='wrong'?'✗':LABELS[i];
              return(
                <button key={i} onClick={()=>toggleOpt(i)}
                  style={{display:'flex',alignItems:'flex-start',gap:10,padding:'10px 12px',borderRadius:10,border:ost.border,background:ost.bg,cursor:revealed?'default':'pointer',textAlign:'left',width:'100%',opacity:ost.opacity||1,transition:'all .12s'}}>
                  <span style={{width:26,height:26,borderRadius:7,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,background:ost.labelBg,color:ost.labelColor}}>{labelTxt}</span>
                  <span style={{fontSize:13,color:'#374151',lineHeight:1.55,flex:1,paddingTop:2}} dangerouslySetInnerHTML={{__html:bold(opt||'(empty)')}}/>
                </button>
              );
            })}
          </div>
        )}

        {/* NAT answer box preview */}
        {q.type==='NAT'&&(
          <div style={{padding:'12px 14px'}}>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{flex:1,padding:'11px 14px',borderRadius:10,border:'2px solid #e5e7eb',background:'#f9fafb',fontSize:14,color:'#9ca3af',fontWeight:600}}>
                Enter numeric answer…
              </div>
              {q.unit&&<span style={{fontSize:13,color:'#9ca3af',fontWeight:600,whiteSpace:'nowrap'}}>{q.unit}</span>}
            </div>
            <div style={{marginTop:10,padding:'8px 12px',background:'#fefce8',borderRadius:8,border:'1px solid #fde68a'}}>
              <span style={{fontSize:11,fontWeight:700,color:'#92400e'}}>Correct answer: </span>
              <span style={{fontSize:12,color:'#78350f',fontWeight:600}}>{q.answer} {q.unit||''}</span>
              {(q.tolerance>0)&&<span style={{fontSize:11,color:'#a16207'}}> (±{q.tolerance})</span>}
            </div>
          </div>
        )}

        {/* Explanation (shown after reveal) */}
        {revealed&&q.explanation&&(
          <div style={{margin:'0 14px 14px',padding:'12px 14px',borderRadius:10,border:`1.5px solid ${isRight?'#86efac':'#fca5a5'}`,background:isRight?'#f0fdf4':'#fef2f2',color:isRight?'#15803d':'#b91c1c',fontSize:12.5,lineHeight:1.6}}>
            <div style={{fontWeight:700,marginBottom:4,fontSize:13}}>{isRight?'🎉 Correct!':'💡 Explanation:'}</div>
            <span dangerouslySetInnerHTML={{__html:bold(q.explanation)}}/>
          </div>
        )}

        {/* Action bar */}
        <div style={{padding:'0 14px 14px',display:'flex',gap:8}}>
          {!revealed?(
            <button onClick={()=>setRevealed(true)} disabled={q.type==='NAT'?false:!hasAnswer}
              style={{...S.btn(color),flex:1,justifyContent:'center',fontSize:13,opacity:(q.type==='NAT'||hasAnswer)?1:0.4}}>
              {q.type==='NAT'?'Show Answer':'Check Answer'}
            </button>
          ):(
            <button onClick={()=>{setRevealed(false);setSelected([]);}}
              style={{...S.btn('#6b7280'),flex:1,justifyContent:'center',fontSize:13}}>
              ↺ Try Again
            </button>
          )}
        </div>
      </div>

      {/* Validation hints */}
      <div style={{padding:'10px 12px',background:'#f0f9ff',borderRadius:8,border:'1px solid #bae6fd',fontSize:11,color:'#0369a1'}}>
        <strong>Answer key:</strong>{' '}
        {q.type==='NAT'
          ? `${q.answer}${q.unit?' '+q.unit:''} (±${q.tolerance||0})`
          : q.answer?.length
            ? q.answer.map(i=>LABELS[i]).join(', ')+' — '+q.answer.map(i=>(q.options||[])[i]||'?').join(' / ')
            : 'No correct answer marked yet'
        }
        {q.type!=='NAT'&&<><br/><strong>Hint:</strong> {q.type==='MCQ'?'Click options to test selection · then Check Answer':'Click multiple options · then Check Answer'}</>}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   SMALL SHARED UI COMPONENTS
══════════════════════════════════════════════════════════════════════════ */
function Shell({ title, children }){
  return(
    <>
      <Head>
        <title>{title}</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.10/dist/katex.min.css"/>
        <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.10/dist/katex.min.js"/>
        <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.10/dist/contrib/auto-render.min.js"/>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
        <style>{`*{box-sizing:border-box;margin:0;padding:0}body{font-family:Inter,system-ui,sans-serif;background:#f4f5fb;color:#1a1a2e}button{font-family:inherit;cursor:pointer}img{max-width:100%;display:block}::-webkit-scrollbar{width:5px;height:5px}::-webkit-scrollbar-thumb{background:#e5e7eb;border-radius:3px}`}</style>
      </Head>
      <div style={{minHeight:'100vh'}}>{children}</div>
    </>
  );
}
function Sec({ title, action, children }){
  return(
    <div style={{padding:'14px 16px',borderBottom:'1px solid #f3f4f6'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
        <span style={S.label}>{title}</span>
        {action}
      </div>
      {children}
    </div>
  );
}
function F({ label, children }){
  return(
    <div style={{marginBottom:12}}>
      {label&&<label style={{display:'block',fontSize:11,fontWeight:700,color:'#6b7280',marginBottom:5}}>{label}</label>}
      {children}
    </div>
  );
}
function IBtn({ children, danger, onClick, title, color }){
  return(
    <button onClick={onClick} title={title} style={{background:'none',border:'none',cursor:'pointer',fontSize:13,padding:'3px 5px',borderRadius:6,color:color||(danger?'#ef4444':'#9ca3af'),display:'flex',alignItems:'center',flexShrink:0}}>
      {children}
    </button>
  );
}
function DashBtn({ onClick, children, style={} }){
  return(
    <button onClick={onClick} style={{width:'100%',padding:8,borderRadius:9,border:'1.5px dashed #d1d5db',background:'none',cursor:'pointer',fontSize:12,fontWeight:600,color:'#9ca3af',marginTop:4,...style}}>
      {children}
    </button>
  );
}
function UploadBtn({ onClick }){
  return(
    <button onClick={onClick} style={{padding:'7px 14px',borderRadius:9,border:'1.5px dashed #d1d5db',background:'#fafafa',cursor:'pointer',fontSize:12,fontWeight:600,color:'#9ca3af',display:'inline-flex',alignItems:'center',gap:6}}>
      📷 Upload Image
    </button>
  );
}

/* ── Shared style tokens ── */
const S = {
  card:      { background:'#fff', borderRadius:16, border:'1px solid #e5e7eb', padding:16, boxShadow:'0 1px 3px rgba(0,0,0,.06)' },
  header:    { background:'#fff', borderBottom:'1px solid #e5e7eb', height:56, display:'flex', alignItems:'center', gap:12, padding:'0 20px', boxShadow:'0 1px 3px rgba(0,0,0,.06)', position:'sticky', top:0, zIndex:40 },
  logo:      { width:34, height:34, borderRadius:10, background:'linear-gradient(135deg,#7c3aed,#4f46e5)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, color:'#fff', fontSize:11 },
  label:     { fontSize:11, fontWeight:700, color:'#374151', textTransform:'uppercase', letterSpacing:'.05em' },
  inp:       { width:'100%', padding:'9px 12px', borderRadius:9, border:'1.5px solid #e5e7eb', background:'#f9fafb', fontSize:13, fontFamily:'inherit', outline:'none', color:'#111' },
  btn:       (bg='#6C3FF5') => ({ display:'inline-flex', alignItems:'center', gap:6, padding:'9px 18px', borderRadius:10, border:'none', background:bg, color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }),
  btnOutline:{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 14px', borderRadius:10, border:'1.5px solid #e5e7eb', background:'#fff', color:'#6b7280', fontSize:13, fontWeight:600, cursor:'pointer', fontFamily:'inherit' },
  loginCard: { background:'#fff', borderRadius:22, width:'100%', maxWidth:420, overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,.15)' },
  stripe:    { height:5, background:'linear-gradient(90deg,#7c3aed,#6366f1,#4f46e5)' },
  bigLogo:   { width:52, height:52, borderRadius:16, margin:'0 auto 14px', background:'linear-gradient(135deg,#7c3aed,#4f46e5)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, color:'#fff', fontSize:15 },
  center:    { display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh', padding:16 },
};
