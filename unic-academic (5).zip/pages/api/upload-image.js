import { isAdmin } from '../../lib/auth';
import { storeImage } from '../../lib/image-upload';

export const config = { api: { bodyParser: { sizeLimit: '8mb' } } };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  if (!isAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const { dataUri, filename } = req.body || {};
    if (!dataUri) return res.status(400).json({ error: 'dataUri required' });
    const result = await storeImage(dataUri, filename || 'image.png');
    res.json(result);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}
