import { hasuraRequest } from '../../../lib/hasura';
import { isAdmin } from '../../../lib/auth';

const Q = `query {
  registrations_aggregate { aggregate { count } }
  attempts_aggregate { aggregate { count } }
  correct: attempts_aggregate(where:{is_correct:{_eq:true}}) { aggregate { count } }
  today_regs: registrations_aggregate(where:{created_at:{_gte:"${new Date().toISOString().slice(0,10)}"}}) { aggregate { count } }
}`;

export default async function handler(req, res) {
  if (!isAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const d = await hasuraRequest(Q);
    const total   = d.attempts_aggregate.aggregate.count;
    const correct = d.correct.aggregate.count;
    res.json({
      registrations : d.registrations_aggregate.aggregate.count,
      attempts      : total,
      accuracy      : total ? `${Math.round(correct/total*100)}%` : '—',
      todayRegs     : d.today_regs.aggregate.count,
    });
  } catch (e) {
    res.status(200).json({ error: e.message, configured: e.code === 'HASURA_NOT_CONFIGURED' ? false : null });
  }
}
