import { hasuraRequest } from '../../../lib/hasura';
import { isAdmin } from '../../../lib/auth';

const Q = `query($limit:Int!,$offset:Int!){
  rows:registrations(order_by:{created_at:desc},limit:$limit,offset:$offset){
    id name email mobile source ip created_at
  }
  total:registrations_aggregate{ aggregate{count} }
}`;

export default async function handler(req, res) {
  if (!isAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
  const limit  = Math.min(parseInt(req.query.limit  || '50'), 200);
  const offset = parseInt(req.query.offset || '0');
  try {
    const d = await hasuraRequest(Q, { limit, offset });
    res.json({ rows: d.rows, total: d.total.aggregate.count });
  } catch (e) {
    res.status(200).json({ rows:[], total:0, error: e.message });
  }
}
