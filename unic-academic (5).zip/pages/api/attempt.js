import { hasuraRequest } from '../../lib/hasura';

const INSERT = `mutation Insert($o: attempts_insert_input!) {
  insert_attempts_one(object: $o) { id }
}`;

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const { userId='anon', questionId, subject, chapterId, questionType, selected, correct, isCorrect=false } = req.body || {};
    if (!questionId || !subject || !chapterId) return res.status(400).json({ error: 'questionId, subject, chapterId required' });
    const id = `att_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    await hasuraRequest(INSERT, { o: { id, user_id:userId, question_id:questionId, subject, chapter_id:chapterId, question_type:questionType||null, selected:selected??null, correct:correct??null, is_correct:!!isCorrect } });
    res.json({ success: true, id });
  } catch (e) {
    console.error('[attempt]', e.message);
    res.json({ success: true, warning: e.message });
  }
}
