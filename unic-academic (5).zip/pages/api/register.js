import { hasuraRequest } from '../../lib/hasura';

const INSERT = `mutation Insert($o: registrations_insert_input!) {
  insert_registrations_one(object: $o) { id }
}`;

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const { name='', email='', mobile='', source='' } = req.body || {};
    if (!name.trim() && !email.trim()) return res.status(400).json({ error: 'name or email required' });
    const id = `reg_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const ip = (req.headers['x-forwarded-for']||'').split(',')[0].trim() || '';
    await hasuraRequest(INSERT, { o: { id, name:name.trim(), email:email.trim(), mobile:mobile.trim(), source:source.trim(), ip } });
    res.json({ success: true, id });
  } catch (e) {
    console.error('[register]', e.message);
    // Don't block UX on DB errors — registration is optional
    res.json({ success: true, warning: e.message });
  }
}
