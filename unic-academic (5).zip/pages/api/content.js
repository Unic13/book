import { hasuraRequest } from '../../lib/hasura';
import { isAdmin } from '../../lib/auth';

const GET_ONE  = `query($code:String!){ subject_content_by_pk(code:$code){ code subject color data updated_at } }`;
const GET_ALL  = `query{ subject_content(order_by:{code:asc}){ code subject color updated_at } }`;
const UPSERT   = `mutation($o:subject_content_insert_input!){
  insert_subject_content_one(object:$o, on_conflict:{constraint:subject_content_pkey, update_columns:[subject,color,data,updated_at]}){ code updated_at }
}`;
const DELETE   = `mutation($code:String!){ delete_subject_content_by_pk(code:$code){ code } }`;

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method === 'GET') {
    try {
      const code = req.query.code;
      if (code) {
        const d = await hasuraRequest(GET_ONE, { code: code.toUpperCase() });
        if (!d.subject_content_by_pk) return res.status(404).json({ error: 'Not found' });
        return res.json(d.subject_content_by_pk);
      }
      const d = await hasuraRequest(GET_ALL);
      return res.json({ subjects: d.subject_content });
    } catch (e) {
      return res.status(200).json({ error: e.message, configured: false });
    }
  }

  if (!isAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });

  if (req.method === 'POST') {
    const { code, subject, color, data } = req.body || {};
    if (!code || !subject || !data) return res.status(400).json({ error: 'code, subject, data required' });
    try {
      const r = await hasuraRequest(UPSERT, { o: { code:code.toUpperCase(), subject, color:color||'#6C3FF5', data, updated_at:new Date().toISOString() } });
      return res.json({ success: true, code: r.insert_subject_content_one.code });
    } catch (e) {
      return res.status(200).json({ error: e.message, configured: e.code==='HASURA_NOT_CONFIGURED'?false:null });
    }
  }

  if (req.method === 'DELETE') {
    const code = req.query.code;
    if (!code) return res.status(400).json({ error: 'code required' });
    try {
      await hasuraRequest(DELETE, { code: code.toUpperCase() });
      return res.json({ success: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  res.status(405).end();
}
