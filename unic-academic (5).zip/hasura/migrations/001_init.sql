-- ════════════════════════════════════════════════════
--  UNIC Academic — Hasura/Postgres Schema
--  Run this in Hasura Console → Data → SQL
--  Then: Data → Track Table for each table
-- ════════════════════════════════════════════════════

-- User registrations
CREATE TABLE IF NOT EXISTS registrations (
  id         TEXT PRIMARY KEY,
  name       TEXT,
  email      TEXT,
  mobile     TEXT,
  source     TEXT,
  ip         TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_reg_email      ON registrations(email);
CREATE INDEX IF NOT EXISTS idx_reg_created_at ON registrations(created_at DESC);

-- Question attempts
CREATE TABLE IF NOT EXISTS attempts (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  question_id   TEXT NOT NULL,
  subject       TEXT NOT NULL,
  chapter_id    TEXT NOT NULL,
  question_type TEXT,
  selected      JSONB,
  correct       JSONB,
  is_correct    BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_att_user      ON attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_att_subject   ON attempts(subject);
CREATE INDEX IF NOT EXISTS idx_att_created   ON attempts(created_at DESC);

-- Subject content (units → chapters → concept + questions)
-- Stored as a JSONB document matching the /data/*.json schema.
-- Admin Question Builder upserts here; the main app reads this first,
-- falling back to the static /data/*.json files if no DB row exists.
-- Images are stored as Vercel Blob URLs (preferred) or base64 data URIs.
CREATE TABLE IF NOT EXISTS subject_content (
  code       TEXT PRIMARY KEY,   -- 'PH' | 'CH' | 'MA' | 'BIO' | custom
  subject    TEXT NOT NULL,
  color      TEXT,
  data       JSONB NOT NULL,     -- full subject document
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
